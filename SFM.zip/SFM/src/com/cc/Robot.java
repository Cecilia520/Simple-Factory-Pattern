package com.cc;

public interface Robot {
	public void speak();
}
