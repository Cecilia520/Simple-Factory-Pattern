package com.cc;

public class Woman implements Human{
	public void think(){
		System.out.println("Ů�˻�˼����");
	}
}
