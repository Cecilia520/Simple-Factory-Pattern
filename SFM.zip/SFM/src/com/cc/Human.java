package com.cc;

public interface Human {
	public void think();
}
