package com.cc;
//�����˹���
public class RobotFactory extends AbstractFactory{
	public <T extends Robot>T createRobot(Class<T> type1) {
		Robot robot=null;
		return (T)robot;
	}

	@Override
	public <T extends Human> T createHuman(Class<T> type) {
		// TODO Auto-generated method stub
		return null;
	}
}
