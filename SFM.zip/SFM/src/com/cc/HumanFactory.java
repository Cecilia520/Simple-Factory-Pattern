package com.cc;

public class HumanFactory extends AbstractFactory{
	public <T extends Human>T createHuman(Class<T> type) {
		Human human=null;
		return (T) human;
	}
}
